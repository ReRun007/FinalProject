<?php 
    header("location: ../product/view_product.php")
?>


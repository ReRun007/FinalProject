<?php 
    header("location: customerLogin/signin.php")
?>